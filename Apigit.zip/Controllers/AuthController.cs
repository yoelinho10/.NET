﻿using Api.DTOs;
using Api.Entities;
using Api.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly IAuthenticationRepository AuthenticationRepository;
        private readonly ILogger<AuthController> Logger;
        private readonly IConfiguration _config;

        public AuthController(
            IAuthenticationRepository authenticationRepository,
            ILogger<AuthController> logger,
            IConfiguration configuration
            )
        {
            AuthenticationRepository = authenticationRepository;
            Logger = logger;
            _config = configuration;
        }

        [HttpPost("login-adfs")]
        [AllowAnonymous]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Produces(typeof(Response<AuthToken>))]
        public async Task<IActionResult> MdcADFS([FromBody] AuthToken token)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    var AdmissionToken = await AuthenticationRepository.TokenMdcADFS(token.Token!);

                    if (AdmissionToken == null)
                    {
                        throw new Exception("User Creation failed");
                    }
                    else
                    {
                        return Created("", new Response<AuthToken> { Success = true, Resp = AdmissionToken });
                    }
                }
                else
                {
                    return Ok(new Response<AuthToken> { Success = false, Errors = ModelState.Values.SelectMany(modelState => modelState.Errors).Select(e => e.ErrorMessage).ToArray() });
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e, "MdcADFS failed. Error: {0}", e.Message);
                return Ok(new Response<AuthToken> { Success = false, Errors = new string[] { e.Message } });
            }
        }


        [HttpPost("email/validate")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Produces(typeof(Response<AuthToken>))]
        public async Task<IActionResult> ValidateEmailAuthorization([FromBody] EmailValidation input)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string? ip;

                    ip = GetHeaderValueAs<string>("X-Forwarded-For")?.TrimEnd(',').Split(',').Select(s => s.Trim()).FirstOrDefault();

                    // RemoteIpAddress is always null in DNX RC1 Update1 (bug).
                    if (string.IsNullOrWhiteSpace(ip) && this.HttpContext?.Connection?.RemoteIpAddress != null)
                        ip = this.HttpContext.Connection.RemoteIpAddress.ToString();

                    if (string.IsNullOrWhiteSpace(ip))
                        ip = GetHeaderValueAs<string>("REMOTE_ADDR");

                    // _httpContextAccessor.HttpContext?.Request?.Host this is the local host.

                    if (string.IsNullOrWhiteSpace(ip))
                        ip = "";


                    if (!await AuthenticationRepository.ValidateCaptcha(ip!, input.captchaToken))
                    {
                        throw new Exception("Invalid Captcha");
                    }

                    var token = await AuthenticationRepository.ValidateEmailAuthorization(input.Email, input.code);

                    if (token == null)
                    {
                        throw new Exception("Invalid token");
                    }
                    else
                    {
                        return Created("", new Response<AuthToken> { Success = true, Resp = token });
                    }
                }
                else
                {
                    return Ok(new Response<AuthToken> { Success = false, Errors = ModelState.Values.SelectMany(modelState => modelState.Errors).Select(e => e.ErrorMessage).ToArray() });
                }
            }
            catch (Exception e)
            {
                Logger.LogError(e, "ValidateEmailAuthorization failed. Error: {0}, Email: {1}", e.Message, input?.Email ?? "null");
                return Ok(new Response<AuthToken> { Success = false, Errors = new String[] { e.Message } });
            }
        }


        [HttpGet("email/{email}/code")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Produces(typeof(Response<string>))]
        public async Task<IActionResult> EmailCodeGenerationAsync(string email)
        {
            try
            {
                if (string.IsNullOrEmpty(email))
                {
                    throw new ArgumentNullException(nameof(email));
                }

                var code = await AuthenticationRepository.EmailCodeGenerationAsync(email);

                //return Ok(new Response<string>() { Success = true, Resp=code});
                return Ok(new Response<string>() { Success = true, Resp = "" });

            }
            catch (Exception e)
            {
                Logger.LogError(e, "Email Authorization failed {Email}", email ?? "");
                return Ok(new Response<string>() { Success = false, Errors = new string[] { e.Message } });
            }
        }

        private T GetHeaderValueAs<T>(string headerName)
        {
            StringValues values;

            if (this.HttpContext?.Request?.Headers?.TryGetValue(headerName, out values) ?? false)
            {
                string rawValues = values.ToString();

                if (!string.IsNullOrWhiteSpace(rawValues))
                    return (T)Convert.ChangeType(values.ToString(), typeof(T));
            }
            return default(T);
        }
    }

    public class EmailValidation
    {
        [Required]
        [EmailAddress()]
        public string Email { get; set; } = "";

        [Required]
        public string code { get; set; } = "";

        [Required]
        public string captchaToken { get; set; } = "";
    }
}
