﻿using Api.DTOs;
using Api.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Graph.Models;
using System.Security.Claims;

namespace Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ExampleController : Controller
    {
        private readonly ILogger<AuthController> _logger;
        private readonly IConfiguration _config;
        private readonly IExampleRepository<Api.Repositories.Person> _exampleRepo;
        public ExampleController( ILogger<AuthController> logger, IConfiguration configuration, IExampleRepository<Api.Repositories.Person> exampleRepo)
        {
            _exampleRepo = exampleRepo;
            _logger = logger;
            _config = configuration;
        }


        [HttpPost("search")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Produces(typeof(TableResponse<IQueryable<Api.Repositories.Person>>))]
        public IActionResult Search([FromBody] TableDto<Api.Repositories.Person> model)
        {
            try
            {
                var query = _exampleRepo.Search();
                return Ok(model.Process(query));               
             
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error Searching. Error: {0}", e.Message);
                return Ok(new Response<Organization> { Success = false, Errors = new string[] { e.Message } });
            }
        }
    }
}
