﻿using System.ComponentModel.DataAnnotations;

namespace Api.DTOs
{
    public class AuthToken
    {
        public string? FullName { get; set; }
        public string? Email { get; set; }
        [Required]
        public string Token { get; set; }
    }
}
