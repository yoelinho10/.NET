﻿using System.Text.Json.Serialization;

namespace Api.DTOs
{
    public class CaptchaResponse
    {
        public bool success { get; set; }
        [JsonPropertyName("error-codes")]
        public string[]? error_codes { get; set; }
        public DateTime? challenge_ts { get; set; }
        public string? hostname { get; set; }
    }
}
