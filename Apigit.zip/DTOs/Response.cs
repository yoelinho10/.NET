﻿namespace Api.DTOs
{
    public class Response<T>
    {
        public bool Success { get; set; }
        public IEnumerable<string>? Errors { get; set; }

        public T? Resp { get; set; }

    }
}
