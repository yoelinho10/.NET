﻿using Api.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Linq;
using System.Linq.Expressions;
using System.Linq.Expressions;
using Api.Utils;
using System.Reflection;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Reflection.Metadata;
using System.Data.Common;
using System.Text;
using System.Data.SqlClient;


namespace Api.DTOs
{
    public class TableDto<T> where T : class
    {
        public int Take { get; set; }
        public int Page { get; set; }
        private int Skip { get  { return Page == 1 ? 0 : Take * (Page - 1); } }
        public string? sortField { get; set; }
        public bool? sortAsc { get; set; }
        public List<TableFieldDto> Fields { get; set; } = null!;         
       
        public TableResponse<T> Process(IQueryable<T> query)
        {
            try {
                var fields = Fields.Where(x => !string.IsNullOrEmpty(x.Query));

                foreach (var field in fields)
                {
                    switch (field.FieldType)
                    {
                        case "text":
                            query = BuildQueryForText(query, field.FieldName, field.Query, field.SelectedCondition);
                            break;
                        case "decimal":
                            var q = decimal.Parse(field.Query);
                            query = BuildQueryForDecimals(query, field.FieldName, q, field.SelectedCondition);
                            break;
                        case "date":
                            query = BuildQueryForDates(query, field.FieldName, DateTime.Parse(field.Query).Date, field.SelectedCondition);
                            break;
                        case "datetime":
                            query = BuildQueryForDateTimes(query, field.FieldName, DateTime.Parse(field.Query), field.SelectedCondition);
                            break;
                        case "boolean":
                            query = BuildQueryForBoolean(query, field.FieldName, field.Query);
                            break;
                    }
                }

                if (!String.IsNullOrEmpty(sortField))
                    query = query.OrderByField(sortField, sortAsc);

                var total = query.Count();

                query = query.Skip(Skip).Take(Take);

                return new TableResponse<T> { Resp = query, TotalCount = total, Success = true };
            }
            catch (Exception ex)
            {

                return new TableResponse<T> { Success = false, Errors = new string[] { ex.Message }, Resp = null, ShowErrorDescriptionInClient= true };
            }
            
        }

        private  IQueryable<T> BuildQueryForText<T>(IQueryable<T> source, string fieldName, string value, string selectedCondition )
        {
            ParameterExpression obj = Expression.Parameter(typeof(T), "o");
            
            var prop = fieldName.Split('.').Select(x=> ExtensionMethods.UppercaseFirst(x)).Aggregate((Expression)obj, Expression.Property);

            IQueryable<T> result = null;
            
            
            switch (selectedCondition)
            {
                case "contain":
                    result = GenericExpression(source,"Contains", obj, prop, value, typeof(string));
                break;
                case "not_contain":
                    result = NotContains(source, obj, prop, value);
                    break;
                case "start_with":
                    result = GenericExpression(source, "StartsWith", obj, prop, value, typeof(string));
                    break;
                case "end_with":
                    result = GenericExpression(source, "EndsWith", obj, prop, value, typeof(string));
                    break;
                case "=":
                    result = GenericExpression(source, "Equals", obj, prop, value, typeof(string));
                    break;
                case "!=":
                    result = NotEqual(source, obj, prop, value);
                    break;
                default:
                    result = GenericExpression(source, "Contains", obj, prop, value, typeof(string));
                    break;
            }
            
            return result;
        }


        private IQueryable<T> BuildQueryForBoolean<T>(IQueryable<T> source, string fieldName, string value)
        {
            var valueFormatted = ExtensionMethods.UppercaseFirst(value);
            
            if(valueFormatted.Equals("Null"))
                return source;

            ParameterExpression obj = Expression.Parameter(typeof(T), "o");

            var prop = fieldName.Split('.').Select(x => ExtensionMethods.UppercaseFirst(x)).Aggregate((Expression)obj, Expression.Property);

            var final = Expression.Not(Expression.NotEqual(Expression.Convert(prop, typeof(bool)), Expression.Constant(Boolean.Parse(valueFormatted)))) ;

            var lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);

        }

        private IQueryable<T> BuildQueryForDecimals<T>(IQueryable<T> source, string fieldName, decimal value, string selectedCondition)
        {
            ParameterExpression obj = Expression.Parameter(typeof(T), "o");

            var prop = fieldName.Split('.').Select(x => ExtensionMethods.UppercaseFirst(x)).Aggregate((Expression)obj, Expression.Property);

            Expression final = null;
            Expression<Func<T, bool>> lambda = null;

            switch (selectedCondition)
            {
                case ">":                    
                    final = Expression.GreaterThan(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value));                       
                    break;
                case ">=":
                    final = Expression.GreaterThanOrEqual(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value));
                    break;
                case "<":
                    final = Expression.LessThan(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value));
                    break;
                case "<=":
                    final = Expression.LessThanOrEqual(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value));
                    break;
                case "=":
                    final = Expression.Equal(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value));
                    break;
                case "!=":
                    final = Expression.Not(Expression.Equal(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value)));
                    break;
                default:
                    final = Expression.Equal(Expression.Convert(prop, typeof(decimal)), Expression.Constant(value));
                    break;
            }

            lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);
        }

        private IQueryable<T> BuildQueryForDates<T>(IQueryable<T> source, string fieldName, DateTime value, string selectedCondition)
        {
            ParameterExpression obj = Expression.Parameter(typeof(T), "o");

            var prop = fieldName.Split('.').Select(x => ExtensionMethods.UppercaseFirst(x)).Aggregate((Expression)obj, Expression.Property);

            Expression final = null;
            Expression<Func<T, bool>> lambda = null;

            MethodInfo methodEqual = typeof(DateTime).GetMethod("Equals", [typeof(DateTime)])!;
            MethodInfo methodCompare = typeof(DateTime).GetMethod("CompareTo", [typeof(DateTime)])!;
            
            var left = Expression.Property(prop, "Date");

            switch (selectedCondition)
            {
                case ">":
                    final = Expression.GreaterThan(Expression.Call(left, methodCompare, Expression.Property(Expression.Constant(value), "Date")), Expression.Constant(0));
                    break;
                case ">=":
                    final = Expression.GreaterThanOrEqual(Expression.Call(left, methodCompare, Expression.Property(Expression.Constant(value), "Date")), Expression.Constant(0));
                    break;
                case "<":
                    final = Expression.LessThan(Expression.Call(left, methodCompare, Expression.Property(Expression.Constant(value), "Date")), Expression.Constant(0));
                    break;
                case "<=":
                    final = Expression.LessThanOrEqual(Expression.Call(left, methodCompare, Expression.Property(Expression.Constant(value), "Date")), Expression.Constant(0));
                    break;
                case "=":
                    final = Expression.Call(left, methodEqual, Expression.Property(Expression.Constant(value), "Date"));
                    break;
                case "!=":
                    final = Expression.Not(Expression.Call(left, methodEqual, Expression.Property(Expression.Constant(value), "Date")));                    
                    break;
                default:
                    final = Expression.Call(left, methodEqual, Expression.Property(Expression.Constant(value), "Date"));
                    break;
            }

            lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);
        }

        private IQueryable<T> BuildQueryForDateTimes<T>(IQueryable<T> source, string fieldName, DateTime value, string selectedCondition)
        {
            ParameterExpression obj = Expression.Parameter(typeof(T), "o");

            var prop = fieldName.Split('.').Select(x => ExtensionMethods.UppercaseFirst(x)).Aggregate((Expression)obj, Expression.Property);

            Expression final = null;
            Expression<Func<T, bool>> lambda = null;

            MethodInfo methodEqual = typeof(DateTime).GetMethod("Equals", [typeof(DateTime)])!;
            MethodInfo methodIntEqual = typeof(int).GetMethod("Equals", [typeof(int)])!;
            MethodInfo methodCompare = typeof(DateTime).GetMethod("CompareTo", [typeof(DateTime)])!;

            var leftDate = Expression.Property(prop, "Date");
            var leftHour =  Expression.Property(prop, "Hour");
            var leftMinutes = Expression.Property(prop, "Minute");

            var right = Expression.Constant(value);
            var rightDate = Expression.Property(right, "Date");
            var rightHour = Expression.Property(right, "Hour");
            var rightMinute = Expression.Property(right, "Minute");

            switch (selectedCondition)
            {
                case ">":
                    final = Expression.GreaterThan(leftDate, rightDate);
                    final = Expression.Or(final, Expression.And(Expression.Equal(leftDate, rightDate), Expression.GreaterThan(leftHour, rightHour)));
                    final = Expression.Or(final, Expression.And(Expression.And(Expression.Equal(leftDate, rightDate), Expression.Equal(leftHour, rightHour)), Expression.GreaterThan(leftMinutes, rightMinute)));
                    break;
                case ">=":
                    final = Expression.GreaterThanOrEqual(Expression.Call(prop, methodCompare,Expression.Constant(value)), Expression.Constant(0));
                    break;
                case "<":
                    final = Expression.LessThan(leftDate, rightDate);
                    final = Expression.Or(final, Expression.And(Expression.Equal(leftDate, rightDate), Expression.LessThan(leftHour, rightHour)));
                    final = Expression.Or(final, Expression.And(Expression.And(Expression.Equal(leftDate, rightDate), Expression.Equal(leftHour, rightHour)), Expression.LessThan(leftMinutes, rightMinute)));
                    
                    break;
                case "<=":
                    final = Expression.LessThan(leftDate, rightDate);
                    final = Expression.Or(final, Expression.And(Expression.Equal(leftDate, rightDate), Expression.LessThan(leftHour, rightHour)));
                    final = Expression.Or(final, Expression.And(Expression.And(Expression.Equal(leftDate, rightDate), Expression.Equal(leftHour, rightHour)), Expression.LessThanOrEqual(leftMinutes, rightMinute)));
                    break;
                case "=":
                    final = Expression.Call(leftDate, methodEqual, rightDate);
                    final = Expression.And(final, Expression.Call(leftMinutes, methodIntEqual, rightMinute));
                    final = Expression.And(final, Expression.Call(leftHour, methodIntEqual, rightHour));
                    break;
                case "!=":
                    final = Expression.Call(leftDate, methodEqual, rightDate);
                    final = Expression.And(final, Expression.Call(leftMinutes, methodIntEqual, rightMinute));
                    final = Expression.And(final, Expression.Call(leftHour, methodIntEqual, rightHour));
                    final = Expression.Not(final);
                    break;
                default:
                    final = Expression.Call(leftDate, methodEqual, rightDate);
                    final = Expression.And(final, Expression.Call(leftMinutes, methodIntEqual, rightMinute));
                    final = Expression.And(final, Expression.Call(leftHour, methodIntEqual, rightHour));
                    break;
            }

            lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);
        }

        private IQueryable<T> NotContains<T>(IQueryable<T> source, ParameterExpression obj, Expression prop, string value)
        {

            MethodInfo containsMethod = typeof(string).GetMethod("Contains", [typeof(string)])!;

            Expression final = Expression.Not(Expression.Call(prop, containsMethod, Expression.Constant(value)));

            Expression<Func<T, bool>> lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);

        }

        private IQueryable<T> NotEqual<T>(IQueryable<T> source, ParameterExpression obj, Expression prop, string value)
        {

            MethodInfo containsMethod = typeof(string).GetMethod("Equals", [typeof(string)])!;

            Expression final = Expression.Not(Expression.Call(prop, containsMethod, Expression.Constant(value)));

            Expression<Func<T, bool>> lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);

        }

        private IQueryable<T> GenericExpression<T>(IQueryable<T> source, string method, ParameterExpression obj, Expression prop, object value, System.Type type)
        {

            MethodInfo containsMethod = type.GetMethod(method, [type])!;

            Expression final = Expression.Call(prop, containsMethod, Expression.Constant(value));

            Expression<Func<T, bool>> lambda = Expression.Lambda<Func<T, bool>>(final, obj);

            return source.Where(lambda);

        }

      


    }

    public static class ExtensionMethods
    {


        public static string UppercaseFirst(string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        public static IQueryable<T> OrderByField<T>(this IQueryable<T> q, string SortField, bool? Ascending)
        {
            ParameterExpression param = Expression.Parameter(typeof(T), "o");

            var prop = SortField.Split('.').Select(x => ExtensionMethods.UppercaseFirst(x)).Aggregate((Expression)param, Expression.Property);


            // var param = Expression.Parameter(typeof(T), "p");
            //var prop = Expression.Property(param, SortField);
            var exp = Expression.Lambda(prop, param);
            string method = Ascending == true ? "OrderBy" : "OrderByDescending";
            Type[] types = new Type[] { q.ElementType, exp.Body.Type };
            var mce = Expression.Call(typeof(Queryable), method, types, q.Expression, exp);
            return q.Provider.CreateQuery<T>(mce);
        }
    }




        public class TableDtoRawSql
    {
        public int Take { get; set; }
        public int Page { get; set; }
        private int Skip { get { return Page == 1 ? 0 : Take * (Page - 1); } }
        public string? sortField { get; set; }
        public bool? sortAsc { get; set; }
        public List<TableFieldDto> Fields { get; set; } = null!;

        public TableResponse<object> Process( string tableName, string whereQuery, SqlConnection sqlConnection)
        {
            try
            {

                this.Fields = this.Fields.Where(x => !string.IsNullOrEmpty(x.FieldName)).ToList();

                sqlConnection.Open();
                var fields = Fields.Where(x => !string.IsNullOrEmpty(x.Query));

                var query = new StringBuilder(whereQuery);

                foreach (var field in fields)
                {
                    switch (field.FieldType)
                    {
                        case "text":
                            query.Append(BuildQueryForText(UppercaseFirst(field.FieldName) , field.Query, field.SelectedCondition));
                            break;
                        case "decimal":
                            var q = decimal.Parse(field.Query);
                            query.Append(BuildQueryForDecimals(UppercaseFirst(field.FieldName), q, field.SelectedCondition));
                            break;
                        case "date":
                            query.Append(BuildQueryForDates(UppercaseFirst(field.FieldName), DateTime.Parse(field.Query).Date, field.SelectedCondition));
                            break;
                        case "datetime":
                            query.Append(BuildQueryForDateTimes(UppercaseFirst(field.FieldName), DateTime.Parse(field.Query), field.SelectedCondition));
                            break;
                        case "boolean":
                            query.Append(BuildQueryForBoolean(UppercaseFirst(field.FieldName), field.Query));
                            break;
                    }
                }

                var queryString = query.ToString();

                if (queryString.StartsWith(" AND")) {
                    queryString = queryString.Remove(0, 4);
                }

              
                
                var total = GetTotal(queryString, tableName, sqlConnection);

                if (String.IsNullOrEmpty(sortField))
                {
                    queryString += $" ORDER BY {UppercaseFirst(this.Fields.First().FieldName)} DESC ";
                }
                else
                {
                    var sort = sortAsc == true ? "ASC" : "DESC";
                    queryString += $" ORDER BY {UppercaseFirst(sortField)} {sort} ";
                }

                queryString += $" OFFSET {Skip} ROWS FETCH NEXT {Take} ROWS ONLY";

                

                //not records found
                if (total == 0) {
                    sqlConnection.Close();
                    return new TableResponse<object> { Resp = new List<object>(), TotalCount = total, Success = true };
                }

                var result = RunQuery(queryString, tableName, sqlConnection);

                sqlConnection.Close();

                return new TableResponse<object> { Resp = result, TotalCount = total, Success = true };

            }
            catch (Exception ex)
            {

                sqlConnection.Close();
                return new TableResponse<object> { Success = false, Errors = new string[] { ex.Message }, Resp = null, ShowErrorDescriptionInClient = true };
            }

        }

        private int GetTotal(string query, string tableName, SqlConnection conn) {

            
            
            var txt =$"Select count(*) as Total from {tableName} WHERE {query}";
            SqlCommand command = new SqlCommand(txt, conn);
            
            int result = 0;

            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    result = int.Parse(String.Format("{0}", reader["Total"]));
                }
            }

            return result;

        }

        private List<dynamic> RunQuery(string query, string tableName, SqlConnection conn)
        {
            var fields = String.Join(",", this.Fields.Select(x =>  UppercaseFirst(x.FieldName)).ToArray());

            var q = $"Select {fields} from {tableName} WHERE {query}";


            SqlCommand command = new SqlCommand(q, conn);

            List<dynamic> result = new List<dynamic>();



            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    dynamic record = new System.Dynamic.ExpandoObject();
                    foreach (var field in this.Fields) {

                        var fieldName = UppercaseFirst(field.FieldName);
                        ((IDictionary<String, Object>)record).Add(field.FieldName, String.Format("{0}", reader[fieldName]));
                        
                    }
                    result.Add(record);                    
                }
            }

            return result;

        }

        private string UppercaseFirst(string s)
        {
            if (string.IsNullOrEmpty(s)) return string.Empty;
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        private string BuildQueryForText(string fieldName, string value, string selectedCondition)
        {

            switch (selectedCondition)
            {
                case "contain":
                    return $" AND {fieldName} LIKE '%{value}%'";
                    break;
                case "not_contain":
                    return $" AND {fieldName} NOT LIKE '%{value}%'";
                    break;
                case "start_with":
                    return $" AND {fieldName} LIKE '{value}%'";
                    break;
                case "end_with":
                    return $" AND {fieldName} LIKE '%{value}'";
                    break;
                case "=":
                    return $" AND {fieldName} = '{value}'";
                    break;
                case "!=":
                    return $" AND {fieldName} <> '{value}'";
                    break;
                default:
                    return $" AND {fieldName} = '{value}'";
                    break;
            }
            
        }

        private string BuildQueryForDecimals( string fieldName, decimal value, string selectedCondition)
        {
         

            switch (selectedCondition)
            {
                case ">":
                    return $" AND {fieldName} > {value}";
                    break;
                case ">=":
                    return $" AND {fieldName} >= {value}";
                    break;
                case "<":
                    return $" AND {fieldName} < {value}";
                    break;
                case "<=":
                    return $" AND {fieldName} <= {value}";
                    break;
                case "=":
                    return $" AND {fieldName} = {value}";
                    break;
                case "!=":
                    return $" AND {fieldName} <> {value}";
                    break;
                default:
                    return $" AND {fieldName} = {value}";
                    break;
            }

            
        }

        private string BuildQueryForDates(string fieldName, DateTime value, string selectedCondition)
        {
            var dateValue = $"{value.Month}-{value.Day}-{value.Year}";

            switch (selectedCondition)
            {
                case ">":
                    return $" AND CAST({fieldName} as date) >  '{dateValue}'";
                    break;
                case ">=":
                    return $" AND CAST({fieldName} as date) >=  '{dateValue}'";
                    break;
                case "<":
                    return $" AND CAST({fieldName} as date) <  '{dateValue}'";
                    break;
                case "<=":
                    return $" AND CAST({fieldName} as date) <=  '{dateValue}'";
                    break;
                case "=":
                    return $" AND CAST({fieldName} as date) =  '{dateValue}'";
                    break;
                case "!=":
                    return $" AND CAST({fieldName} as date) <>  '{dateValue}'";
                    break;
                default:
                    return $" AND CAST({fieldName} as date) =  '{dateValue}'";
                    break;
            }

            
        }

    
        private string BuildQueryForDateTimes(string fieldName, DateTime value, string selectedCondition)
        {


            switch (selectedCondition)
            {
                case ">":
                    return $" AND {fieldName} >  '{value.ToString()}'";
                    break;
                case ">=":
                    return $" AND {fieldName} >=  '{value.ToString()}'";
                    break;
                case "<":
                    return $" AND {fieldName} <  '{value.ToString()}'";
                    break;
                case "<=":
                    return $" AND {fieldName} <=  '{value.ToString()}'";
                    break;
                case "=":
                    return $" AND {fieldName} = '{value.ToString()}'";
                    break;
                case "!=":
                    return $" AND {fieldName} <>  '{value.ToString()}'";
                    break;
                default:
                    return $" AND {fieldName} =  '{value.ToString()}'";
                    break;
            }

           
        }


        private string BuildQueryForBoolean(string fieldName, string value)
        {
            switch (value)
            {
                case "true":
                    return $" AND {fieldName} =  1";
                    break;
                case "false":
                    return $" AND {fieldName} = 0";
                    break;
                default:
                    return "";
                    break;
            }



        }

       
       
 
       

        

    }

}
