﻿namespace Api.DTOs
{
    public class TableFieldDto
    {
        public string? FieldName { get; set; }
        public string? FieldType { get; set; }  //text || decimal || date || datetime
        public string? Query { get; set; }
        public string? SelectedCondition { get; set; }
        public bool? orderAsc { get; set; }



    }


}
