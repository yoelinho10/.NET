﻿namespace Api.DTOs
{
    public class TableResponse<T>
    {
        public bool Success { get; set; }
        public IEnumerable<string>? Errors { get; set; }
        public IEnumerable<T>? Resp { get; set; }
        public int TotalCount { get; set; }
        public bool ShowErrorDescriptionInClient { get; set; } = true;
    }
}
