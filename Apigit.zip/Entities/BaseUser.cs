﻿using Microsoft.AspNetCore.Identity;

namespace Api.Entities
{
    public class BaseUser : IdentityUser
    {
        public string? UserType { get; set; }
        public string? FullName { get; set; }
    }
}
