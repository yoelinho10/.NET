﻿namespace Api.Entities
{
    public class PublicException : Exception
    {
        public PublicException(string? message) : base(message)
        {
        }
    }
}
