using AdmissionAPI.Data.Entities;
using Api.DTOs;
using Api.Entities;
using Api.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using System.Text;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);


// Must specify the ApplicationId in the appsettings.json
// In case your app was created in infrastructure and you specified a SecretKey yo must include it

int appId = int.Parse(builder.Configuration["ApplicationId"]);
builder.Configuration.AddMDCConfiguration(
    appId,
    builder.Configuration["Secret-Key"],
    new TimeSpan(0, int.Parse(String.IsNullOrWhiteSpace(builder.Configuration["CacheInMinutes"]) ? "60" : builder.Configuration["CacheInMinutes"]), 0));

builder.Logging.AddExceptionLogger(c =>
{
    c.AppId = appId;
});



string appCorsDefinition = "_appCorsDefinition";
string AllowedOrigins = builder.Configuration.GetValue<string>("AllowedOrigins") ?? "";

builder.Services.AddCors(options =>
{
    options.AddPolicy(name: appCorsDefinition,
                      policy =>
                      {
                          policy.WithOrigins(AllowedOrigins.Split(","));
                          policy.AllowAnyHeader();
                          policy.AllowAnyMethod();
                      });
});


builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
    options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Local;
    options.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
    options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
})
    .ConfigureApiBehaviorOptions(options =>
    {
        options.InvalidModelStateResponseFactory = actionContext =>
        {
            var modelState = actionContext.ModelState.Values;
            return new BadRequestObjectResult(new Response<string>()
            {
                Success = false,
                Resp = "One or more validation errors occurred.",
                Errors = modelState.SelectMany(modelState => modelState.Errors).Select(e => e.ErrorMessage).ToArray()
            });
        };
    });



builder.Services.AddScoped<IAuthenticationRepository, AuthenticationRepository>();
builder.Services.AddScoped<IExampleRepository<Api.Repositories.Person>, ExampleRepository>();

builder.Services
    .AddAuthentication(options => options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(cfg => {
        cfg.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
        {
            ValidIssuer = builder.Configuration["Token:Issuer"],
            ValidAudience = builder.Configuration["Token:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Token:Key"])),
            RequireExpirationTime = true,
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(5)
        };
    }
    );
builder.Services.AddDbContext<BaseContext>();
builder.Services.AddIdentity<BaseUser, IdentityRole>(cfg =>
{
    // Password settings.
    cfg.Password.RequireDigit = true;
    cfg.Password.RequireLowercase = true;
    cfg.Password.RequireNonAlphanumeric = true;
    cfg.Password.RequireUppercase = true;
    cfg.Password.RequiredLength = 6;
    cfg.Password.RequiredUniqueChars = 1;

    // Lockout settings.
    cfg.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
    cfg.Lockout.MaxFailedAccessAttempts = 5;
    cfg.Lockout.AllowedForNewUsers = true;

    // User settings.
    cfg.User.RequireUniqueEmail = true;
    //cfg.Tokens.ChangeEmailTokenProvider()
    cfg.SignIn.RequireConfirmedAccount = true;

    cfg.Tokens.EmailConfirmationTokenProvider = "Authorization";
})
     .AddEntityFrameworkStores<BaseContext>()
     .AddDefaultTokenProviders()
     .AddEmailTotpTokenProvider();


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "API", Version = "v1" });
    c.UseAllOfForInheritance();
});

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
    app.UseCors(appCorsDefinition);
}

app.UsePathBase(new PathString("/api"));
app.UseRouting();
//app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
