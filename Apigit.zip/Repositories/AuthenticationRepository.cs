﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Runtime.Intrinsics.Arm;
using System.Security.Claims;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Configuration;
using Api.Entities;
using System.Text;
using Api.DTOs;

namespace Api.Repositories
{
    public class AuthenticationRepository : IAuthenticationRepository
    {
        private readonly ILogger<AuthenticationRepository> _logger;
        private readonly IConfiguration _configuration;
        private readonly UserManager<BaseUser> _userManager;
        public AuthenticationRepository(
          ILogger<AuthenticationRepository> logger,
           UserManager<BaseUser> userManager,

          IConfiguration configuration)
        {
            _logger = logger;
            _userManager = userManager;
            _configuration = configuration;            
        }

        public async Task<string> EmailCodeGenerationAsync(string email)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(email);
                email = email.ToLower().Trim();

                if (user == null)
                {
                    user = new BaseUser { UserName = email, Email = email, FullName = "" };
                    var result = await _userManager.CreateAsync(user);
                }
                else
                {
                   
                    var result = await _userManager.UpdateAsync(user);
                }

                var code = await _userManager.GenerateUserTokenAsync(
                                    user,
                                    "Phone",
                                    "email-validation");

                _logger.LogInformation($"This is the token: {code}");

                //await EmailSender.SendEmailSmtp(new MailRequest()
                //{
                //    ToEmail = new string[] { email },
                //    Subject = Configuration["Authentication:Admission:EmailSubject"],
                //    Body = Configuration["Authentication:Admission:EmailBody"].Replace("{CODE}", code)
                //});

                return code;
            }
            catch (PublicException e)
            {

                _logger.LogError(e, e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e, e.Message);
                throw new Exception("Error while sending confirmation code.");
            }
        }

        public async Task<AuthToken> TokenMdcADFS(string token)
        {
           
            try
            {
                
                var ADFSDomain = _configuration["ADFS:ADFSDomain"];
                var ADFSIssuer = _configuration["ADFS:ADFSIssuer"];
                var ADFSAudience = _configuration["ADFS:ADFSAudience"];


                if (string.IsNullOrWhiteSpace(token))
                {
                    throw new ArgumentNullException("token");
                }

                // Download the OIDC configuration which contains the JWKS
                // NB!!: Downloading this takes time, so do not do it very time you need to validate a token, Try and do it only once in the lifetime of your application!!

                IConfigurationManager<OpenIdConnectConfiguration> configurationManager =
                    new ConfigurationManager<OpenIdConnectConfiguration>($"{ADFSDomain}/.well-known/openid-configuration", new OpenIdConnectConfigurationRetriever());

                OpenIdConnectConfiguration openIdConfig = await configurationManager.GetConfigurationAsync(CancellationToken.None);

                // Configure the TokenValidationParameters. Assign the SigningKeys which were downloaded from ADFS. 
                // Also set the Issuer and Audience(s) to validate.
                // Note: You need to set the ADFS domain as above so that the program can find the /adfs/.well-known/openid-configuration endpoint.
                //       However, this is not the issuer in the token so you need to add the /adfs/services/trust endpoint as below.
                //       If this is not configured corrrectly, you get the exception:

                //       Message=IDX10205: Issuer validation failed. Issuer: 'http://my-adfs/adfs/services/trust'. 
                //       Did not match: validationParameters.ValidIssuer: 'https://my-adfs/adfs/' or validationParameters.ValidIssuers: 'null'.

                TokenValidationParameters validationParameters =
                    new TokenValidationParameters
                    {
                        ValidIssuer = ADFSIssuer,
                        ValidAudiences = new[] { ADFSAudience },
                        IssuerSigningKeys = openIdConfig.SigningKeys
                    };

                // Now validate the token. If the token is not valid for any reason, an exception will be thrown by the method

                SecurityToken validatedToken;
                JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
                var MDCuser = handler.ValidateToken(token, validationParameters, out validatedToken);

                // The ValidateToken method above will return a ClaimsPrincipal. Get the claims form user.Claims.
                // These are OAuth claims e.g. "aud", "iss" etc.

                //_logger.LogInformation("Token is validated");

                //foreach (var Claim in MDCuser.Claims)
                //{
                //    _logger.LogInformation("Claim is " + Claim);
                //}



                if (MDCuser != null)
                {

                   
                    var email = MDCuser.Claims.FirstOrDefault(w => w.Type == "preferred_username");
                    var name = MDCuser.Claims.FirstOrDefault(w => w.Type == "name");
                    var user = new AuthToken { Email = email.Value, FullName = name.Value };

                    user = getJwtToken(user);

                    return user;
                }
                else
                {
                    throw new PublicException("User not found");
                }
            }

            catch (PublicException e)
            {
                _logger.LogError(e, e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e, e.Message);
                throw new Exception("Error while authenticating");
            }

        }

        private AuthToken getJwtToken(AuthToken user)
        {

            List<Claim> claims = new List<Claim>();
            var uniqueName = user.Email.Split("@").First();
            claims.Add(new Claim(JwtRegisteredClaimNames.Email, user.Email));
            claims.Add(new Claim(JwtRegisteredClaimNames.Name, user.FullName));
            claims.Add(new Claim(JwtRegisteredClaimNames.UniqueName, uniqueName));
            //claims.Add(new Claim(MdcClaims.TrackerPermission, roles.Any(x => x.TrackerAppsFull == true).ToString()));
            

            //foreach (var role in roles)
            //    claims.Add(new Claim(ClaimTypes.Role, role.Id));


            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Token:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(

                _configuration["Token:Issuer"],
                _configuration["Token:Audience"],
                claims,
                signingCredentials: creds,
                expires: DateTime.Now.AddMinutes(int.Parse(_configuration["Token:Expires"])));

            user.Token = new JwtSecurityTokenHandler().WriteToken(token);
            return user;
        }

        public async Task<bool> ValidateCaptcha(string ip, string captchaToken)
        {
            bool isValidResponse = false;
            try
            {
                Dictionary<string, string> postD = new Dictionary<string, string>
                {
                    { "secret", _configuration["Authentication:Captcha:Secret"] },
                    { "response", captchaToken },
                    { "remoteip", ip }
                };

                HttpClient client = new();
                HttpResponseMessage resp = await client.PostAsync(_configuration["Authentication:Captcha:URL"], new FormUrlEncodedContent(postD));
                resp.EnsureSuccessStatusCode();
                CaptchaResponse? responseBody = await resp.Content.ReadFromJsonAsync<CaptchaResponse>();
                isValidResponse = responseBody?.success ?? false;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
            }

            return isValidResponse;
        }

        public async Task<AuthToken> ValidateEmailAuthorization(string email, string code)
        {
            try
            {
                if (string.IsNullOrEmpty(email))
                {
                    throw new ArgumentNullException("email");
                }
                if (string.IsNullOrEmpty(code))
                {
                    throw new ArgumentNullException("code");
                }


                var user = await _userManager.FindByEmailAsync(email);
                if (user != null)
                {
                    //IdentityResult


                    bool confirmed = await _userManager.VerifyUserTokenAsync(
                        user,
                        "Phone",
                        "email-validation",
                        code);

                    //bool confirmed = await UserManager.VerifyChangePhoneNumberTokenAsync(
                    //    user,
                    //    user.Email,
                    //    Input.code);
                    if (confirmed)
                    {

                        return getJwtToken(new AuthToken { Email = email, FullName = user.FullName });
                    }
                    else
                    {
                        throw new PublicException("Invalid token");
                    }
                }
                else
                {
                    throw new PublicException("Invalid Email");
                }

            }
            catch (PublicException e)
            {
                _logger.LogError(e, e.Message);
                throw;
            }
            catch (Exception e)
            {
                _logger.LogError(e, e.Message);
                throw new Exception("Error while validating confirmation code.");
            }
        }



    }
}
