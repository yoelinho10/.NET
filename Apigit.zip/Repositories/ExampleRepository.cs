﻿using Api.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Graph.Models;

namespace Api.Repositories
{
    public class ExampleRepository : IExampleRepository<Person>
    {
        public IQueryable<Person> Search()
        {
           return  new Person[] {
            new Person { FullName = "Emma Johnson", Email = "emma.johnson@email.com", Dob = new DateTime(1990, 5, 15), Gender = "Female" },
            new Person { FullName = "Liam Smith", Email = "liam.smith@email.com", Dob = new DateTime(1988, 9, 23), Gender = "Male" },
            new Person { FullName = "Olivia Brown", Email = "olivia.brown@email.com", Dob = new DateTime(1992, 3, 7), Gender = "Female" },
            new Person { FullName = "Noah Davis", Email = "noah.davis@email.com", Dob = new DateTime(1985, 11, 30), Gender = "Male" },
            new Person { FullName = "Ava Miller", Email = "ava.miller@email.com", Dob = new DateTime(1993, 7, 18), Gender = "Female" },
            new Person { FullName = "Elijah Wilson", Email = "elijah.wilson@email.com", Dob = new DateTime(1987, 2, 9), Gender = "Male" },
            new Person { FullName = "Sophia Moore", Email = "sophia.moore@email.com", Dob = new DateTime(1991, 10, 25), Gender = "Female" },
            new Person { FullName = "James Taylor", Email = "james.taylor@email.com", Dob = new DateTime(1989, 6, 12), Gender = "Male" },
            new Person { FullName = "Isabella Anderson", Email = "isabella.anderson@email.com", Dob = new DateTime(1994, 4, 3), Gender = "Female" },
            new Person { FullName = "William Thomas", Email = "william.thomas@email.com", Dob = new DateTime(1986, 8, 20), Gender = "Male" },
            new Person { FullName = "Charlotte Jackson", Email = "charlotte.jackson@email.com", Dob = new DateTime(1995, 1, 5), Gender = "Female" },
            new Person { FullName = "Benjamin White", Email = "benjamin.white@email.com", Dob = new DateTime(1984, 12, 28), Gender = "Male" },
            new Person { FullName = "Mia Harris", Email = "mia.harris@email.com", Dob = new DateTime(1993, 9, 14), Gender = "Female" },
            new Person { FullName = "Lucas Martin", Email = "lucas.martin@email.com", Dob = new DateTime(1988, 3, 22), Gender = "Male" },
            new Person { FullName = "Amelia Thompson", Email = "amelia.thompson@email.com", Dob = new DateTime(1992, 7, 9), Gender = "Female" },
            new Person { FullName = "Henry Garcia", Email = "henry.garcia@email.com", Dob = new DateTime(1987, 5, 17), Gender = "Male" },
            new Person { FullName = "Harper Martinez", Email = "harper.martinez@email.com", Dob = new DateTime(1996, 2, 1), Gender = "Female" },
            new Person { FullName = "Alexander Robinson", Email = "alexander.robinson@email.com", Dob = new DateTime(1985, 10, 11), Gender = "Male" },
            new Person { FullName = "Evelyn Clark", Email = "evelyn.clark@email.com", Dob = new DateTime(1994, 6, 26), Gender = "Female" },
            new Person { FullName = "Jackson Lewis", Email = "jackson.lewis@email.com", Dob = new DateTime(1989, 4, 8), Gender = "Male" },
            new Person { FullName = "Abigail Lee", Email = "abigail.lee@email.com", Dob = new DateTime(1991, 11, 19), Gender = "Female" },
            new Person { FullName = "Sebastian Walker", Email = "sebastian.walker@email.com", Dob = new DateTime(1986, 8, 3), Gender = "Male" },
            new Person { FullName = "Ella Hall", Email = "ella.hall@email.com", Dob = new DateTime(1995, 3, 29), Gender = "Female" },
            new Person { FullName = "Aiden Allen", Email = "aiden.allen@email.com", Dob = new DateTime(1984, 12, 7), Gender = "Male" },
            new Person { FullName = "Scarlett Young", Email = "scarlett.young@email.com", Dob = new DateTime(1993, 9, 2), Gender = "Female" },
            new Person { FullName = "Matthew King", Email = "matthew.king@email.com", Dob = new DateTime(1988, 1, 24), Gender = "Male" },
            new Person { FullName = "Grace Wright", Email = "grace.wright@email.com", Dob = new DateTime(1992, 5, 13), Gender = "Female" },
            new Person { FullName = "Samuel Scott", Email = "samuel.scott@email.com", Dob = new DateTime(1987, 7, 31), Gender = "Male" },
            new Person { FullName = "Chloe Green", Email = "chloe.green@email.com", Dob = new DateTime(1996, 4, 16), Gender = "Female" },
            new Person { FullName = "David Adams", Email = "david.adams@email.com", Dob = new DateTime(1985, 10, 5), Gender = "Male" },
            new Person { FullName = "Victoria Baker", Email = "victoria.baker@email.com", Dob = new DateTime(1994, 2, 21), Gender = "Female" },
            new Person { FullName = "Joseph Gonzalez", Email = "joseph.gonzalez@email.com", Dob = new DateTime(1989, 6, 8), Gender = "Male" },
            new Person { FullName = "Aria Nelson", Email = "aria.nelson@email.com", Dob = new DateTime(1991, 12, 27), Gender = "Female" },
            new Person { FullName = "Carter Carter", Email = "carter.carter@email.com", Dob = new DateTime(1986, 8, 14), Gender = "Male" },
            new Person { FullName = "Madison Mitchell", Email = "madison.mitchell@email.com", Dob = new DateTime(1995, 3, 1), Gender = "Female" },
            new Person { FullName = "Owen Perez", Email = "owen.perez@email.com", Dob = new DateTime(1984, 11, 10), Gender = "Male" },
            new Person { FullName = "Luna Roberts", Email = "luna.roberts@email.com", Dob = new DateTime(1993, 7, 23), Gender = "Female" },
            new Person { FullName = "Wyatt Turner", Email = "wyatt.turner@email.com", Dob = new DateTime(1988, 1, 6), Gender = "Male" },
            new Person { FullName = "Zoe Phillips", Email = "zoe.phillips@email.com", Dob = new DateTime(1992, 5, 19), Gender = "Female" },
            new Person { FullName = "John Campbell", Email = "john.campbell@email.com", Dob = new DateTime(1987, 9, 4), Gender = "Male" },
            new Person { FullName = "Nora Parker", Email = "nora.parker@email.com", Dob = new DateTime(1996, 2, 28), Gender = "Female" },
            new Person { FullName = "Luke Evans", Email = "luke.evans@email.com", Dob = new DateTime(1985, 10, 17), Gender = "Male" },
            new Person { FullName = "Riley Edwards", Email = "riley.edwards@email.com", Dob = new DateTime(1994, 4, 9), Gender = "Female" },
            new Person { FullName = "Isaac Collins", Email = "isaac.collins@email.com", Dob = new DateTime(1989, 8, 22), Gender = "Male" },
            new Person { FullName = "Leah Stewart", Email = "leah.stewart@email.com", Dob = new DateTime(1991, 12, 11), Gender = "Female" },
            new Person { FullName = "Gabriel Sanchez", Email = "gabriel.sanchez@email.com", Dob = new DateTime(1986, 6, 30), Gender = "Male" },
            new Person { FullName = "Sofia Morris", Email = "sofia.morris@email.com", Dob = new DateTime(1995, 1, 13), Gender = "Female" },
            new Person { FullName = "Julian Cook", Email = "julian.cook@email.com", Dob = new DateTime(1990, 3, 25), Gender = "Male" }
        }.AsQueryable();
        }
    }

    public class Person {
        public string FullName { get; set; }
        public string Email { get; set; }
        public DateTime Dob { get; set; }
        public string Gender { get; set; }
    }
}
