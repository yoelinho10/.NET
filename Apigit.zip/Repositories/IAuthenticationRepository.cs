﻿using Api.DTOs;
using Api.Entities;

namespace Api.Repositories
{
    public interface IAuthenticationRepository
    {
        Task<AuthToken> TokenMdcADFS(string token);

        Task<bool> ValidateCaptcha(string ip, string captchaToken);

        Task<AuthToken> ValidateEmailAuthorization(string email, string code);
        Task<string> EmailCodeGenerationAsync(string email);
    }
}
