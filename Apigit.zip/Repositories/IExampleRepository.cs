﻿using Microsoft.Graph.Models.Security;

namespace Api.Repositories
{
    public interface IExampleRepository<T>
    {
        IQueryable<T> Search();
    }
}
