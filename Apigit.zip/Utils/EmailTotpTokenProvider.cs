﻿using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using Microsoft.VisualBasic;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace AdmissionAPI.Data.Entities
{
    public class EmailTotpTokenProvider<TUser> : TotpSecurityStampBasedTokenProvider<TUser>
        where TUser : IdentityUser
    {

        public TimeSpan TokenLifespan { get; set; }

        public EmailTotpTokenProvider(){
        }



        public override async Task<bool> CanGenerateTwoFactorTokenAsync(Microsoft.AspNetCore.Identity.UserManager<TUser> manager, TUser user)
        {
            if (manager == null)
            {
                throw new ArgumentNullException(nameof(manager));
            }
            var email = await manager.GetEmailAsync(user);
            return !string.IsNullOrWhiteSpace(email) && ! await manager.IsEmailConfirmedAsync(user);

        }

        public override async Task<string> GetUserModifierAsync(string purpose, UserManager<TUser> manager, TUser user)
        {
            if (manager == null)
            {
                throw new ArgumentNullException(nameof(manager));
            }
            var email = await manager.GetEmailAsync(user);
            return "EmailCode:" + purpose + ":" + email;
        }




        public bool validateGoogle()
        {
            return true;
        }

    }

    public static class CustomIdentityBuilderExtensions
    {
        public static IdentityBuilder AddEmailTotpTokenProvider(this IdentityBuilder builder)
        {
            var userType = builder.UserType;
            var totpProvider = typeof(EmailTotpTokenProvider<>).MakeGenericType(userType);
            return builder.AddTokenProvider("EmailTotpTokenProvider", totpProvider);
        }
    }

    public class EmailTotpTokenProviderOptions : DataProtectionTokenProviderOptions
    {
        public EmailTotpTokenProviderOptions()
        {
            // update the defaults
            Name = "EmailTotpTokenProvider";
            TokenLifespan = TimeSpan.FromMinutes(15);
        }
    }


}