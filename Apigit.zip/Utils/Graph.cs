using Azure;
using Azure.Core;
using Azure.Identity;
using Microsoft.Graph;
using Microsoft.Graph.Models;
using System.Net;

namespace Api.Utils
{
    public class GraphUtil
    {

        private GraphServiceClient _graphClient;
        private ClientSecretCredential _clientSecretCredential;
        IConfiguration _configuration;
        public GraphUtil(IConfiguration configuration)
        {
            _configuration = configuration;

            var clientId = _configuration["AzureAd:ClientId"];
            var tenantId = _configuration["AzureAd:TenantId"];
            var secret = _configuration["AzureAd:ClientSecret"];

            //var userId = "6f34bbec-d179-41e7-a660-064f2cea8e7f";//Julio
            //var userId = "abd6188b-361f-44cc-bc47-de9ff3632794";//Mio

            var scopes = new[] { "https://graph.microsoft.com/.default" };


            var options = new OnBehalfOfCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud,
            };

            _clientSecretCredential = new ClientSecretCredential(tenantId, clientId, secret);

            _graphClient = new GraphServiceClient(_clientSecretCredential, scopes);




        }

        public async Task<List<string>> GetUserGroups(string id)
        {
            var result = new List<string>();
            try
            {
                var response = await _graphClient.Users[id].MemberOf.GraphGroup.GetAsync(requestConfiguration =>
                {
                    requestConfiguration.QueryParameters.Top = 100;
                });

                var pageIterator = PageIterator<Microsoft.Graph.Models.Group, Microsoft.Graph.Models.GroupCollectionResponse>
                    .CreatePageIterator(_graphClient, response, (group) =>
                    {
                        result.Add(group.Id);
                        return true;
                    });

                await pageIterator.IterateAsync();



            }
            catch (System.Exception ex)
            {
                int a = 34;
            }
            return result;

        }

        public async Task<List<string>> GetUsersInGroup(string id)
        {
            var result = new List<string>();
            try
            {
                var response = await _graphClient.Groups[id].Members.GetAsync();

                response.Value.ForEach(x =>
                {
                    result.Add(x.Id);
                });

                // var pageIterator = PageIterator<Microsoft.Graph.Models.Group, Microsoft.Graph.Models.GroupCollectionResponse>
                //    .CreatePageIterator(_graphClient, response, (group) =>
                //    {
                //        result.Add(group.Id);
                //        return true;
                //    });
                // await pageIterator.IterateAsync();



            }
            catch (System.Exception ex)
            {
                int a = 34;
            }
            return result;

        }



    }

    public class GraphParams
    {
        public string ClientId { get; set; }
        public string Tenant { get; set; }
    }
}
