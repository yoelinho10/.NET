﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NLog.Web;

namespace MyApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //Set deafult proxy
            WebRequest.DefaultWebProxy = new WebProxy("http://127.0.0.1:8118", true) { UseDefaultCredentials = true };

            var logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
            try
            {
                logger.Debug("init main");
                CreateWebHostBuilder(args).Build().Run();   // CreateWebHostBuilder(args): Este método estático crea un constructor del host web 
                                                            // Build() Este método construye el host web y configura todo lo necesario para que la aplicación se ejecute.
                                                            //.Run() lo que inicia el servidor web y hace que la aplicación empiece a escuchar las solicitudes HTTP entrantes.
            }
            catch (Exception ex)
            {
                //NLog: catch setup errors
                logger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                NLog.LogManager.Shutdown();
            }
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .ConfigureLogging(options => options.ClearProviders()) //Esto se hace para evitar la duplicación de registros si se están utilizando otros proveedores de registro, como NLog.
                .UseNLog()      //NLog es un popular marco de registro y este método lo configura para que sea el proveedor de registro principal de la aplicación.
                .UseStartup<Startup>();   // Este método especifica la clase de inicio (Startup) que se utilizará para configurar la aplicación.
                                          // La clase Startup es donde se configuran los servicios de la aplicación y se establecen las rutas y el comportamiento de los controladores.
    }
}
