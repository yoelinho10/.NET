﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using AutoMapper;
using Common;
using Data;
using Data.Repositories;
using ElmahCore.Mvc;
using ElmahCore.Sql;
using Entities;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MyApi.Models;
using Services;
using Services.DataInitializer;
using Swashbuckle.AspNetCore.Swagger;
using WebFramework;
using WebFramework.Configuration;
using WebFramework.CustomMapping;
using WebFramework.Middlewares;
using WebFramework.Swagger;

namespace MyApi
{
    public class Startup
    {
        private readonly SiteSettings _siteSetting;
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;

            AutoMapperConfiguration.InitializeAutoMapper();

            _siteSetting = configuration.GetSection(nameof(SiteSettings)).Get<SiteSettings>();
        }


        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.Configure<SiteSettings>(Configuration.GetSection(nameof(SiteSettings)));//Este método se utiliza para configurar las opciones de la aplicación. 
                                                                                             //Configuration.GetSection(nameof(SiteSettings)): Este método obtiene la sección correspondiente a las opciones SiteSettings del archivo de configuración.
            services.AddDbContext(Configuration);//el código que proporcionas registra un contexto de base de datos en la aplicación ASP.NET Core utilizando la configuración proporcionada en Configuration.
                                                 //Esto permite que la aplicación acceda y trabaje con la base de datos utilizando Entity Framework Core.

            services.AddCustomIdentity(_siteSetting.IdentitySettings);//agrega la autenticación de identidad a tu aplicación ASP.NET Core utilizando opciones de configuración específicas _siteSetting.IdentitySettings.
                                                                      //Esto permite que tu aplicación utilice la autenticación de identidad con la configuración personalizada proporcionada.

            services.AddMinimalMvc();//diseñado para proporcionar una configuración mínima de MVC que permita ejecutar una aplicación web básica sin agregar funcionalidades o componentes innecesarios.

            services.AddElmah(Configuration, _siteSetting); //agrega Elmah a tu aplicación ASP.NET Core, lo que te permite registrar y gestionar fácilmente los errores que ocurran en la aplicación. 

            services.AddJwtAuthentication(_siteSetting.JwtSettings);//extensión personalizada que agrega la autenticación JWT (JSON Web Token) a tu aplicación ASP.NET Core.
                                                                    //JwtSettings es una propiedad de esta clase que contiene la configuración específica de JWT para tu aplicación.
                                                                    //Esta configuración puede incluir cosas como la clave secreta, el emisor, el público objetivo, etc.
            services.AddCustomApiVersioning();//diseñado para proporcionar una configuración personalizada y flexible de versiones de API en tu aplicación ASP.NET Core. 

            services.AddSwagger();//permite generar automáticamente la documentación de tu API web y proporcionar una interfaz de usuario interactiva para explorar y probar la API

            return services.BuildAutofacServiceProvider();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseRateLimitMiddleware();

            app.IntializeDatabase();

            app.UseCustomExceptionHandler();

            app.UseHsts(env);

            app.UseElmah();

            app.UseHttpsRedirection();

            app.UseSwaggerAndUI();

            app.UseAuthentication();

            app.UseMvc();
        }
    }
}
