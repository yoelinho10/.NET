﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace WebFramework.Middlewares
{
    
    public class RateLimitMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IRateLimitService _rateLimitService;

        public RateLimitMiddleware(RequestDelegate next, IRateLimitService rateLimitService)
        {
            _next = next;
            _rateLimitService = rateLimitService;
        }

        public async Task Invoke(HttpContext context)
        {
            var clientId = context.Connection.RemoteIpAddress.ToString(); // Get client IP address or unique identifier

            if (_rateLimitService.IsRateLimited(clientId))
            {
                context.Response.StatusCode = StatusCodes.Status429TooManyRequests;
                await context.Response.WriteAsync("Rate limit exceeded. Please try again later.");
                return;
            }

            await _next(context);
        }
    }

    public interface IRateLimitService
    {
        bool IsRateLimited(string clientId);
    }

    public class RateLimitService : IRateLimitService
    {
        private readonly ICacheProvider _cacheProvider; // Implement ICacheProvider to store request counts

        public RateLimitService(ICacheProvider cacheProvider)
        {
            _cacheProvider = cacheProvider;
        }

        public bool IsRateLimited(string clientId)
        {
            // Implement logic to check and enforce rate limit
            // Example: Check request count for clientId within a fixed time frame window
            // If count exceeds limit, return true; otherwise, return false
            return true;
        }
    }

    public static class RateLimitMiddlewareExtensions
    {
        public static IApplicationBuilder UseRateLimitMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RateLimitMiddleware>();
        }
    }
}
